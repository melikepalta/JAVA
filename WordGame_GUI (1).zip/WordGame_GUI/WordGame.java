// Melike Palta
// CS 1181 - Make your Game Project

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;
import java.util.List;

public class WordGame extends JFrame {
    private List<String> words;
    private List<String> validWordsList;
    private String currentWord;
    private int score;
    private JTextField inputField;
    private JTextArea outputArea;
    private Random rand;
    private JLabel imageLabel;
    private String originalWord; // added this later on to store the original unshuffled word

    public WordGame() throws IOException { //constructor method
        words = new ArrayList<>();
        validWordsList = new ArrayList<>();
        rand = new Random();

        loadWords(); //i added this here to show the shuffled word to the user

        setTitle("~GUESS THE WORD~");
        setSize(1550, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new BorderLayout());

        inputField = new JTextField();
        add(inputField, BorderLayout.NORTH);

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        add(new JScrollPane(outputArea), BorderLayout.CENTER);

        createButtons();
        startGame();

        imageLabel = new JLabel(new ImageIcon("happy.jpg"));
        imageLabel.setVisible(false); // keeps the image hidden
        add(imageLabel, BorderLayout.SOUTH); // adds the image when the user gets a word right

        inputField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                processInput(inputField.getText());
                inputField.setText("");
            }
        });
    }

    private void createButtons() {
        JPanel buttonPanel = new JPanel();

        JButton mixButton = new JButton("Mix");
        mixButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentWord = shuffleWord(originalWord); // reshuffles                                                                        the original word
                displayGameElements();
            }
        });

        JButton nextButton = new JButton("Next");
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                validWordsList.clear();
                score = 0;
                originalWord = getRandomUniqueWord(); // gets a new word
                currentWord = shuffleWord(originalWord);
                displayGameElements();
            }
        });

        JButton byeButton = new JButton("Bye");
        byeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        JButton lsButton = new JButton("LS");
        lsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayValidWordsList();
            }
        });

        buttonPanel.add(mixButton);
        buttonPanel.add(nextButton);
        buttonPanel.add(lsButton);
        buttonPanel.add(byeButton);
        add(buttonPanel, BorderLayout.EAST);
    }

    private void loadWords() {
        try {
            Scanner scanner = new Scanner(new File("words.txt"));
            while (scanner.hasNext()) {
                String word = scanner.next();
                if (word.length() >= 4) {
                    words.add(word);
                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void startGame() {
        originalWord = getRandomUniqueWord(); // stores the original unshuffled word
        currentWord = shuffleWord(originalWord);
        displayGameElements();
    }

    private String getRandomUniqueWord() {
        List<String> sevenLetterWords = new ArrayList<>();

        for (String word : words) {
            if (word.length() == 7) {
                Set<Character> uniqueChars = new HashSet<>();
                for (char c : word.toCharArray()) {
                    uniqueChars.add(c);
                }
                if (uniqueChars.size() == 7) {
                    sevenLetterWords.add(word);
                }
            }
        }

        if (!sevenLetterWords.isEmpty()) {
            int randomIndex = rand.nextInt(sevenLetterWords.size());
            return sevenLetterWords.get(randomIndex);
        } else {
            return ""; // this handles the case where there is no valid words
        }
    }

    private void displayGameElements() {
        outputArea.setText(""); // clears the text area before updating
        outputArea.append("\n************ WELCOME TO MY 'GUESS THE WORD' GAME ************\n");
        outputArea.append("\nUnscramble the following letters to make a word: " + shuffleWord(currentWord) + "\n");
        outputArea.append("\nGuess the word, or click on: mix (to reshuffle), next (for a new word), ls (to see the list of words found so far), bye (to end the game):\n");
        outputArea.append("\nScore: " + score + "\n");
    }

    private void displayValidWordsList() {
        outputArea.setText(""); // clears the text area before updating
        if (validWordsList.isEmpty()) {
            outputArea.append("No valid words found yet.\n");
        } else {
            outputArea.append("Valid words found so far:\n");
            for (String word : validWordsList) {
                outputArea.append(word + "\n");
            }
        }
        outputArea.append("Score: " + score + "\n");
    }

    private String shuffleWord(String word) {
        char[] characters = word.toCharArray();
        for (int i = 0; i < characters.length; i++) {
            int randIndex = rand.nextInt(characters.length);
            char temp = characters[i];
            characters[i] = characters[randIndex];
            characters[randIndex] = temp;
        }
        return new String(characters);
    }

    private void processInput(String input) {
        if (input.equalsIgnoreCase("mix")) {
            currentWord = shuffleWord(originalWord); // reshuffles the original word
            displayGameElements();
        } else if (input.equalsIgnoreCase("next")) {
            validWordsList.clear();
            score = 0;
            originalWord = getRandomUniqueWord(); // gets a new original word
            currentWord = shuffleWord(originalWord);
            displayGameElements();
        } else if (input.equalsIgnoreCase("ls")) {
            displayValidWordsList();
        } else if (input.equalsIgnoreCase("bye")) {
            outputArea.append("\nThanks for playing!\n");
            System.exit(0);
        } else {
            int wordScore = getWordScore(input);
            if (wordScore > 0) {
                score += wordScore;
                validWordsList.add(input);
                displayGameElements();
            
                // checks if it's a correct answer and shows the image
                if (isValidWord(input, originalWord)) {
                    showImage(true);
                } else {
                    showImage(false);
                }
            } else {
                showImage(false);
                outputArea.append("Invalid word.\n");
            }
            
            displayGameElements();
        }
    }

    private void showImage(boolean show) {
        imageLabel.setVisible(show);
    }    

    private int getWordScore(String word) {
        if (word.length() >= 4 && word.length() <= 7 && isValidWord(word, originalWord) && isWordInFile(word)) {
            if (word.length() == 4) {
                return 1;
            } else {
                return word.length();
            }
        }
        return 0;
    }

    private boolean isWordInFile(String word) {
        for (String validWord : words) {
            if (word.equalsIgnoreCase(validWord)) {
                return true;
            }
        }
        return false; // if the word is not in the list, it returns the user input as false
    }

    private boolean isValidWord(String word, String currentWord) {
        for (char c : word.toCharArray()) {
            if (currentWord.indexOf(c) == -1) {
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                WordGame wordGame = new WordGame();
                wordGame.setVisible(true);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }
}
