import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import java.util.ArrayList;
import java.util.List;

public class PasswordCracker5Letter {
    // Constants for the original zip file, password length, and number of threads
    private static final String ORIGINAL_ZIP_FILE = "protected5.zip";
    private static final int PASSWORD_LENGTH = 5;
    private static final int NUM_THREADS = 13;

    // The found password
    private static String foundPassword = null;

    // Start the password cracking
    public void crackPasswords() {
        // List of threads
        List<PasswordThread> threads = new ArrayList<>();

        // Threads for cracking
        for (int i = 0; i < NUM_THREADS; i++) {
            String tempZipFile = "temp_zip_" + i + ".zip";
            copyZipFile(ORIGINAL_ZIP_FILE, tempZipFile);

            PasswordThread thread = new PasswordThread(tempZipFile);
            threads.add(thread);
            thread.start();
        }

        // Wait for all threads
        for (PasswordThread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Display result
        if (foundPassword != null) {
            System.out.println("Password cracked! Password: " + foundPassword);
        } else {
            System.out.println("Password not found.");
        }
    }

    // Copy a zip file
    private static void copyZipFile(String sourceFile, String destinationFile) {
        try {
            Files.copy(new File(sourceFile).toPath(), new File(destinationFile).toPath(),
                    StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Thread for cracking
    private static class PasswordThread extends Thread {
        private final String zipFilePath;

        public PasswordThread(String zipFilePath) {
            this.zipFilePath = zipFilePath;
        }

        @Override
        public void run() {
            generatePasswords("", PASSWORD_LENGTH);
        }

        private void generatePasswords(String currentPassword, int remainingLength) {
            if (foundPassword != null) {
                return;
            }

            if (remainingLength == 0) {
                if (checkPassword(currentPassword)) {
                    foundPassword = currentPassword;
                }
                return;
            }

            for (char c = 'a'; c <= 'c'; c++) {
                generatePasswords(currentPassword + c, remainingLength - 1);
            }
        }

        private boolean checkPassword(String password) {
            try {
                ZipFile zFile = new ZipFile(zipFilePath);
                zFile.setPassword(password);
                zFile.extractAll("contents-" + Thread.currentThread().getId());
                return true;
            } catch (ZipException e) {
                return false;
            }
        }
    }

    // Main method to start the cracking
    public static void main(String[] args) {
        PasswordCracker5Letter passwordCracker = new PasswordCracker5Letter();
        passwordCracker.crackPasswords();
    }
}
